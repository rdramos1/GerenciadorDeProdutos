﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GerenciadorProdutos.Entities;

namespace GerenciadorProdutos.Data {
    public class SaleData {
        public List<Sale> Sale { get; set; } = new();

    }
}
