﻿using System.Globalization;
using GerenciadorProdutos.Data;
using GerenciadorProdutos.Entities;
using GerenciadorProdutos.Repositories;
using GerenciadorProdutos.Service;

namespace GerenciadorProdutos {
    public class Program {
        public static void Main(string[] args) {

            var repo = new JsonRepository<AppData>("C:\\temp\\GerenciadorDeProdutos\\data.json");
            var data = repo.GetAll() ?? new AppData();

            InventoryService inv = new InventoryService(data) ?? new InventoryService();
            SaleService sale = new SaleService(data) ?? new SaleService();

            AppDomain.CurrentDomain.ProcessExit += (s, e) => {
                repo.SaveAll(data);
                Console.WriteLine("Data saved to file.");
            };

            if(inv.Products.Count == 0) {
                FillData(inv, sale);
            }

            Menu menu = new Menu(inv, sale);

            try {
                menu.ShowPrincipalMenu();
            } catch (Exception e) {
                Console.WriteLine(e.ToString());
            }
        }
        static void FillData(InventoryService inv, SaleService sale) {
            inv.CreateCategory("Beverages");
            inv.CreateCategory("Snacks");
            inv.CreateCategory("Dairy");
            inv.AddProductByCategory("Coca-Cola", 10, 5.50, inv.Categories[0]);
            inv.AddProductByCategory("Pepsi", 20, 4.50, inv.Categories[0]);
            inv.AddProductByCategory("Chips", 15, 2.50, inv.Categories[1]);
            inv.AddProductByCategory("Cookies", 30, 3.00, inv.Categories[1]);
            inv.AddProductByCategory("Milk", 25, 1.50, inv.Categories[2]);
            inv.AddProductByCategory("Yogurt", 20, 2.00, inv.Categories[2]);
            inv.AddProductByCategory("Cheese", 10, 4.00, inv.Categories[2]);
            sale.RegisterSale(inv.Products[0], 2);
            sale.RegisterSale(inv.Products[1], 1);
            sale.RegisterSale(inv.Products[2], 3);
        }
    }
}









