﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GerenciadorProdutos.Entities;

namespace GerenciadorProdutos.Data {
    public class InventoryData {
        public List<Product> Products { get; set; } = new();
        public List<Category> Categories { get; set; } = new();

    }
}
