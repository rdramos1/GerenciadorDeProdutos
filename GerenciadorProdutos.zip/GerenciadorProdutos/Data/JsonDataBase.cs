﻿using System.Text.Json;
using GerenciadorProdutos.Interfaces;
using GerenciadorProdutos.Service;

namespace GerenciadorProdutos.Data {
    public class JsonDataBase : IDataBase {
        private readonly string _basePath;

        // Novo construtor que aceita o caminho base
        public JsonDataBase(string basePath) {
            _basePath = basePath;
        }

        public T Load<T>(T entity) {
            string path = GetFilePath(entity);
            if (!File.Exists(path)) {
                return entity is SaleRecorder ? (T)(object)new SaleRecorder() :
                       entity is Inventory ? (T)(object)new Inventory() :
                       default(T);
            }

            string json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<T>(json);
        }
        public void Save<T>(T entity) {
            string path = GetFilePath(entity);
            string directory = Path.GetDirectoryName(path);
            if (!Directory.Exists(directory)) {
                Directory.CreateDirectory(directory);
            }
            var options = new JsonSerializerOptions {
                WriteIndented = true,
                ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.Preserve
            };
            string json = JsonSerializer.Serialize(entity, options);
            File.WriteAllText(path, json);
        }

        private string GetFilePath<T>(T entity) {
            string fileName = entity is SaleRecorder ? "SaleRocorder.json" :
                              entity is Inventory ? "Inventory.json" :
                              throw new NotSupportedException("Unsupported entity type.");
            return Path.Combine(_basePath, fileName);
        }
    }
}
