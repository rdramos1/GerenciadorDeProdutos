﻿using GerenciadorProdutos.Entities;
using Newtonsoft.Json;

namespace GerenciadorProdutos.Repositories {
    public class JsonRepository<T> : IRepository<T> {
        private readonly string _filePath;
        public JsonRepository(string filePath) {
            _filePath = filePath;
        }
        public T GetAll() {
            if (!File.Exists(_filePath)) {
                return default(T)!;
            }
            var json = File.ReadAllText(_filePath);
            return JsonConvert.DeserializeObject<T>(json);
        }

        public void SaveAll(T data) {
            var settings = new JsonSerializerSettings {
                Formatting = Formatting.Indented,
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                PreserveReferencesHandling = PreserveReferencesHandling.Objects
            };
            var json = JsonConvert.SerializeObject(data, settings);
            File.WriteAllText(_filePath, json);

        }
    }
}

