﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciadorProdutos.Interfaces {
    public interface IDataBase {
        T Load<T>(T entity);
        void Save<T>(T entity);
    }
}
