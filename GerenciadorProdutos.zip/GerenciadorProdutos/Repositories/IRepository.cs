﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GerenciadorProdutos.Entities;

namespace GerenciadorProdutos.Repositories {
    public interface IRepository<T> {
        public interface IRepository<T> {
            public T GetAll();
            public void SaveAll(T data);
        }

    }
}
