﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciadorProdutos.Data {
    public class AppData {
        public InventoryData InventoryData { get; set; } = new();
        public SaleData SaleData { get; set; } = new();
    }
}
